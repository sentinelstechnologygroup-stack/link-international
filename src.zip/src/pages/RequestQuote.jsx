import React, { useState } from "react";
import PageHero from "../components/shared/PageHero";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Upload, CheckCircle, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

const categories = [
  "Consumer Goods", "Business & Office Supplies", "Tools & Hardware",
  "Household Products", "Automotive Accessories", "Apparel & Textiles",
  "Commercial Supplies", "Special-Order Sourcing", "Other",
];

export default function RequestQuote() {
  const [form, setForm] = useState({
    full_name: "", company_name: "", email: "", phone: "", country: "",
    requester_type: "buyer", product_category: "", product_request: "",
    brand_specs: "", estimated_quantity: "", destination: "", timeline: "",
    is_importer_of_record: "", has_import_permits: "", service_type: "",
    message: "", file_url: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [uploading, setUploading] = useState(false);

  const update = (field, val) => setForm((f) => ({ ...f, [field]: val }));

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    update("file_url", file_url);
    setUploading(false);
    toast.success("File uploaded successfully");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.full_name || !form.email || !form.product_request) {
      toast.error("Please fill in all required fields");
      return;
    }
    setSubmitting(true);
    await base44.entities.QuoteRequest.create(form);
    setSubmitting(false);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <>
        <PageHero headline="Request Submitted" compact />
        <section className="py-24 bg-background">
          <div className="max-w-xl mx-auto px-4 text-center">
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
              <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-8 h-8 text-accent" />
              </div>
              <h2 className="font-display text-2xl font-bold text-foreground mb-4">Thank You</h2>
              <p className="text-muted-foreground leading-relaxed">
                Your sourcing request has been received. Our team will review your requirements and respond with next steps. Please allow 1–3 business days for an initial review.
              </p>
            </motion.div>
          </div>
        </section>
      </>
    );
  }

  return (
    <>
      <PageHero
        headline="Request a Sourcing Quote"
        subheadline="Tell us what you need and our team will review your requirements."
        compact
      />

      <section className="py-24 bg-background">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Contact Info */}
            <div>
              <h3 className="font-semibold text-lg text-foreground mb-4 pb-2 border-b">Contact Information</h3>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Full Name *</Label>
                  <Input value={form.full_name} onChange={(e) => update("full_name", e.target.value)} placeholder="Your full name" />
                </div>
                <div className="space-y-2">
                  <Label>Company Name</Label>
                  <Input value={form.company_name} onChange={(e) => update("company_name", e.target.value)} placeholder="Company name" />
                </div>
                <div className="space-y-2">
                  <Label>Email *</Label>
                  <Input type="email" value={form.email} onChange={(e) => update("email", e.target.value)} placeholder="email@company.com" />
                </div>
                <div className="space-y-2">
                  <Label>Phone / WhatsApp</Label>
                  <Input value={form.phone} onChange={(e) => update("phone", e.target.value)} placeholder="+1 234 567 8900" />
                </div>
                <div className="space-y-2">
                  <Label>Country</Label>
                  <Input value={form.country} onChange={(e) => update("country", e.target.value)} placeholder="e.g., Sri Lanka" />
                </div>
                <div className="space-y-2">
                  <Label>You are a...</Label>
                  <Select value={form.requester_type} onValueChange={(v) => update("requester_type", v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="buyer">Buyer</SelectItem>
                      <SelectItem value="supplier">Supplier</SelectItem>
                      <SelectItem value="partner">Partner</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Product Details */}
            <div>
              <h3 className="font-semibold text-lg text-foreground mb-4 pb-2 border-b">Product Details</h3>
              <div className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Product Category</Label>
                    <Select value={form.product_category} onValueChange={(v) => update("product_category", v)}>
                      <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                      <SelectContent>
                        {categories.map((c) => (<SelectItem key={c} value={c}>{c}</SelectItem>))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Estimated Quantity</Label>
                    <Input value={form.estimated_quantity} onChange={(e) => update("estimated_quantity", e.target.value)} placeholder="e.g., 500 units" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Specific Product Request *</Label>
                  <Textarea value={form.product_request} onChange={(e) => update("product_request", e.target.value)} placeholder="Describe the products you need..." rows={3} />
                </div>
                <div className="space-y-2">
                  <Label>Brand / Specification Details</Label>
                  <Textarea value={form.brand_specs} onChange={(e) => update("brand_specs", e.target.value)} placeholder="Preferred brands, specs, or requirements..." rows={2} />
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Desired Destination</Label>
                    <Input value={form.destination} onChange={(e) => update("destination", e.target.value)} placeholder="e.g., Colombo, Sri Lanka" />
                  </div>
                  <div className="space-y-2">
                    <Label>Desired Timeline</Label>
                    <Input value={form.timeline} onChange={(e) => update("timeline", e.target.value)} placeholder="e.g., 30–60 days" />
                  </div>
                </div>
              </div>
            </div>

            {/* Import Details */}
            <div>
              <h3 className="font-semibold text-lg text-foreground mb-4 pb-2 border-b">Import & Service Details</h3>
              <div className="space-y-6">
                <div className="space-y-3">
                  <Label>Are you the importer of record in Sri Lanka?</Label>
                  <RadioGroup value={form.is_importer_of_record} onValueChange={(v) => update("is_importer_of_record", v)} className="flex flex-wrap gap-4">
                    <div className="flex items-center gap-2"><RadioGroupItem value="yes" id="ior-yes" /><Label htmlFor="ior-yes" className="font-normal">Yes</Label></div>
                    <div className="flex items-center gap-2"><RadioGroupItem value="no" id="ior-no" /><Label htmlFor="ior-no" className="font-normal">No</Label></div>
                    <div className="flex items-center gap-2"><RadioGroupItem value="unsure" id="ior-unsure" /><Label htmlFor="ior-unsure" className="font-normal">Unsure</Label></div>
                  </RadioGroup>
                </div>
                <div className="space-y-3">
                  <Label>Do you have required import permits?</Label>
                  <RadioGroup value={form.has_import_permits} onValueChange={(v) => update("has_import_permits", v)} className="flex flex-wrap gap-4">
                    <div className="flex items-center gap-2"><RadioGroupItem value="yes" id="ip-yes" /><Label htmlFor="ip-yes" className="font-normal">Yes</Label></div>
                    <div className="flex items-center gap-2"><RadioGroupItem value="no" id="ip-no" /><Label htmlFor="ip-no" className="font-normal">No</Label></div>
                    <div className="flex items-center gap-2"><RadioGroupItem value="not_applicable" id="ip-na" /><Label htmlFor="ip-na" className="font-normal">N/A</Label></div>
                    <div className="flex items-center gap-2"><RadioGroupItem value="unsure" id="ip-unsure" /><Label htmlFor="ip-unsure" className="font-normal">Unsure</Label></div>
                  </RadioGroup>
                </div>
                <div className="space-y-3">
                  <Label>Service needed</Label>
                  <RadioGroup value={form.service_type} onValueChange={(v) => update("service_type", v)} className="flex flex-wrap gap-4">
                    <div className="flex items-center gap-2"><RadioGroupItem value="sourcing_only" id="st-so" /><Label htmlFor="st-so" className="font-normal">Sourcing only</Label></div>
                    <div className="flex items-center gap-2"><RadioGroupItem value="sourcing_and_export" id="st-se" /><Label htmlFor="st-se" className="font-normal">Sourcing + Export coordination</Label></div>
                  </RadioGroup>
                </div>
              </div>
            </div>

            {/* Additional */}
            <div>
              <h3 className="font-semibold text-lg text-foreground mb-4 pb-2 border-b">Additional Information</h3>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Additional Message</Label>
                  <Textarea value={form.message} onChange={(e) => update("message", e.target.value)} placeholder="Any additional details..." rows={3} />
                </div>
                <div className="space-y-2">
                  <Label>Upload Product List / Spec Sheet</Label>
                  <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                    <input type="file" onChange={handleFile} className="hidden" id="file-upload" />
                    <label htmlFor="file-upload" className="cursor-pointer">
                      {uploading ? (
                        <Loader2 className="w-6 h-6 text-muted-foreground mx-auto animate-spin" />
                      ) : form.file_url ? (
                        <div className="flex items-center justify-center gap-2 text-accent">
                          <CheckCircle className="w-5 h-5" />
                          <span className="text-sm font-medium">File uploaded</span>
                        </div>
                      ) : (
                        <>
                          <Upload className="w-6 h-6 text-muted-foreground mx-auto mb-2" />
                          <span className="text-sm text-muted-foreground">Click to upload a file</span>
                        </>
                      )}
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Trust Note */}
            <div className="p-4 bg-muted/50 rounded-lg">
              <p className="text-xs text-muted-foreground leading-relaxed">
                Submitting a request does not guarantee product availability, export eligibility, import approval, or final pricing. Our team will review your request and respond with next steps.
              </p>
            </div>

            <Button type="submit" disabled={submitting} className="w-full bg-accent text-accent-foreground hover:bg-accent/90 font-semibold h-12 text-base">
              {submitting ? <Loader2 className="w-5 h-5 animate-spin" /> : "Submit Request"}
            </Button>
          </form>
        </div>
      </section>
    </>
  );
}